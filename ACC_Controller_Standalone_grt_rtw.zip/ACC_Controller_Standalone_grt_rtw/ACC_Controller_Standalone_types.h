/*
 * ACC_Controller_Standalone_types.h
 *
 * Code generation for model "ACC_Controller_Standalone".
 *
 * Model version              : 1.1
 * Simulink Coder version : 26.2 (R2026b) 22-May-2026
 * C source code generated on : Tue Oct 27 15:25:58 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef ACC_Controller_Standalone_types_h_
#define ACC_Controller_Standalone_types_h_

/* Parameters (default storage) */
typedef struct P_ACC_Controller_Standalone_T_ P_ACC_Controller_Standalone_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_ACC_Controller_Standa_T RT_MODEL_ACC_Controller_Stand_T;

#endif                                 /* ACC_Controller_Standalone_types_h_ */
