/*
 * ACC_Controller_Standalone.h
 *
 * Code generation for model "ACC_Controller_Standalone".
 *
 * Model version              : 1.1
 * Simulink Coder version : 26.2 (R2026b) 22-May-2026
 * C source code generated on : Tue Oct 27 15:25:58 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef ACC_Controller_Standalone_h_
#define ACC_Controller_Standalone_h_
#ifndef ACC_Controller_Standalone_COMMON_INCLUDES_
#define ACC_Controller_Standalone_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#include "rt_nonfinite.h"
#include "math.h"
#endif                          /* ACC_Controller_Standalone_COMMON_INCLUDES_ */

#include "ACC_Controller_Standalone_types.h"
#include <float.h>
#include <string.h>
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T v_set;                        /* '<Root>/v_set' */
  real_T v_lead;                       /* '<Root>/v_lead' */
  real_T x_lead;                       /* '<Root>/x_lead' */
  real_T v_ego;                        /* '<Root>/v_ego' */
  real_T x_ego;                        /* '<Root>/x_ego' */
} ExtU_ACC_Controller_Standalon_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T a_cmd;                        /* '<Root>/a_cmd' */
} ExtY_ACC_Controller_Standalon_T;

/* Parameters (default storage) */
struct P_ACC_Controller_Standalone_T_ {
  real_T Gain2_Gain;                   /* Expression: 0.5
                                        * Referenced by: '<Root>/Gain2'
                                        */
  real_T Gain_Gain;                    /* Expression: 1.5
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Constant_Value;               /* Expression: 10
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Gain1_Gain;                   /* Expression: 0.4
                                        * Referenced by: '<Root>/Gain1'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 2
                                        * Referenced by: '<Root>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -3
                                        * Referenced by: '<Root>/Saturation'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_ACC_Controller_Standa_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_ACC_Controller_Standalone_T ACC_Controller_Standalone_P;

/* External inputs (root inport signals with default storage) */
extern ExtU_ACC_Controller_Standalon_T ACC_Controller_Standalone_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_ACC_Controller_Standalon_T ACC_Controller_Standalone_Y;

/* Model entry point functions */
extern void ACC_Controller_Standalone_initialize(void);
extern void ACC_Controller_Standalone_step(void);
extern void ACC_Controller_Standalone_terminate(void);

/* Real-time Model object */
extern RT_MODEL_ACC_Controller_Stand_T *const ACC_Controller_Standalone_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'ACC_Controller_Standalone'
 */
#endif                                 /* ACC_Controller_Standalone_h_ */
