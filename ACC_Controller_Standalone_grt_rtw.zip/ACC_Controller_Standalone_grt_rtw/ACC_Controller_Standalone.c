/*
 * ACC_Controller_Standalone.c
 *
 * Code generation for model "ACC_Controller_Standalone".
 *
 * Model version              : 1.1
 * Simulink Coder version : 26.2 (R2026b) 22-May-2026
 * C source code generated on : Tue Oct 27 15:25:58 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ACC_Controller_Standalone.h"
#include <math.h>
#include "rtwtypes.h"
#include <string.h>
#include "ACC_Controller_Standalone_private.h"

/* External inputs (root inport signals with default storage) */
ExtU_ACC_Controller_Standalon_T ACC_Controller_Standalone_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_ACC_Controller_Standalon_T ACC_Controller_Standalone_Y;

/* Real-time model */
static RT_MODEL_ACC_Controller_Stand_T ACC_Controller_Standalone_M_;
RT_MODEL_ACC_Controller_Stand_T *const ACC_Controller_Standalone_M =
  &ACC_Controller_Standalone_M_;

/* Model step function */
void ACC_Controller_Standalone_step(void)
{
  real_T u0;

  /* MinMax: '<Root>/MinMax' incorporates:
   *  Constant: '<Root>/Constant'
   *  Gain: '<Root>/Gain'
   *  Gain: '<Root>/Gain1'
   *  Gain: '<Root>/Gain2'
   *  Inport: '<Root>/v_ego'
   *  Inport: '<Root>/v_set'
   *  Inport: '<Root>/x_ego'
   *  Inport: '<Root>/x_lead'
   *  Sum: '<Root>/Add'
   *  Sum: '<Root>/Subtract'
   *  Sum: '<Root>/Subtract1'
   *  Sum: '<Root>/Subtract2'
   */
  u0 = fmin((ACC_Controller_Standalone_U.v_set -
             ACC_Controller_Standalone_U.v_ego) *
            ACC_Controller_Standalone_P.Gain2_Gain,
            ((ACC_Controller_Standalone_U.x_lead -
              ACC_Controller_Standalone_U.x_ego) -
             (ACC_Controller_Standalone_P.Gain_Gain *
              ACC_Controller_Standalone_U.v_ego +
              ACC_Controller_Standalone_P.Constant_Value)) *
            ACC_Controller_Standalone_P.Gain1_Gain);

  /* Saturate: '<Root>/Saturation' */
  if (u0 > ACC_Controller_Standalone_P.Saturation_UpperSat) {
    /* Outport: '<Root>/a_cmd' */
    ACC_Controller_Standalone_Y.a_cmd =
      ACC_Controller_Standalone_P.Saturation_UpperSat;
  } else if (u0 < ACC_Controller_Standalone_P.Saturation_LowerSat) {
    /* Outport: '<Root>/a_cmd' */
    ACC_Controller_Standalone_Y.a_cmd =
      ACC_Controller_Standalone_P.Saturation_LowerSat;
  } else {
    /* Outport: '<Root>/a_cmd' */
    ACC_Controller_Standalone_Y.a_cmd = u0;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* Matfile logging */
  rt_UpdateTXYLogVars(ACC_Controller_Standalone_M->rtwLogInfo,
                      (&ACC_Controller_Standalone_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.01s, 0.0s] */
    if ((rtmGetTFinal(ACC_Controller_Standalone_M)!=-1) &&
        !((rtmGetTFinal(ACC_Controller_Standalone_M)-
           ACC_Controller_Standalone_M->Timing.taskTime0) >
          ACC_Controller_Standalone_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(ACC_Controller_Standalone_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if ((++ACC_Controller_Standalone_M->Timing.clockTick0)==0) {
    ++ACC_Controller_Standalone_M->Timing.clockTickH0;
  }

  ACC_Controller_Standalone_M->Timing.taskTime0 =
    ACC_Controller_Standalone_M->Timing.clockTick0 *
    ACC_Controller_Standalone_M->Timing.stepSize0 +
    ACC_Controller_Standalone_M->Timing.clockTickH0 *
    ACC_Controller_Standalone_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void ACC_Controller_Standalone_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)ACC_Controller_Standalone_M, 0,
                sizeof(RT_MODEL_ACC_Controller_Stand_T));
  rtmSetTFinal(ACC_Controller_Standalone_M, 10.0);
  ACC_Controller_Standalone_M->Timing.stepSize0 = 0.01;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = (NULL);
    ACC_Controller_Standalone_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(ACC_Controller_Standalone_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(ACC_Controller_Standalone_M->rtwLogInfo, (NULL));
    rtliSetLogT(ACC_Controller_Standalone_M->rtwLogInfo, "tout");
    rtliSetLogX(ACC_Controller_Standalone_M->rtwLogInfo, "");
    rtliSetLogXFinal(ACC_Controller_Standalone_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(ACC_Controller_Standalone_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(ACC_Controller_Standalone_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(ACC_Controller_Standalone_M->rtwLogInfo, 0);
    rtliSetLogDecimation(ACC_Controller_Standalone_M->rtwLogInfo, 1);
    rtliSetLogY(ACC_Controller_Standalone_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(ACC_Controller_Standalone_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(ACC_Controller_Standalone_M->rtwLogInfo, (NULL));
  }

  /* external inputs */
  (void)memset(&ACC_Controller_Standalone_U, 0, sizeof
               (ExtU_ACC_Controller_Standalon_T));

  /* external outputs */
  ACC_Controller_Standalone_Y.a_cmd = 0.0;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(ACC_Controller_Standalone_M->rtwLogInfo, 0.0,
    rtmGetTFinal(ACC_Controller_Standalone_M),
    ACC_Controller_Standalone_M->Timing.stepSize0, (&rtmGetErrorStatus
    (ACC_Controller_Standalone_M)));
}

/* Model terminate function */
void ACC_Controller_Standalone_terminate(void)
{
  /* (no terminate code required) */
}
