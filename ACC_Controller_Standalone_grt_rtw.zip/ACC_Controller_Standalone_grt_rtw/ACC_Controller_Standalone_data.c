/*
 * ACC_Controller_Standalone_data.c
 *
 * Code generation for model "ACC_Controller_Standalone".
 *
 * Model version              : 1.1
 * Simulink Coder version : 26.2 (R2026b) 22-May-2026
 * C source code generated on : Tue Oct 27 15:25:58 2026
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ACC_Controller_Standalone.h"

/* Block parameters (default storage) */
P_ACC_Controller_Standalone_T ACC_Controller_Standalone_P = {
  /* Expression: 0.5
   * Referenced by: '<Root>/Gain2'
   */
  0.5,

  /* Expression: 1.5
   * Referenced by: '<Root>/Gain'
   */
  1.5,

  /* Expression: 10
   * Referenced by: '<Root>/Constant'
   */
  10.0,

  /* Expression: 0.4
   * Referenced by: '<Root>/Gain1'
   */
  0.4,

  /* Expression: 2
   * Referenced by: '<Root>/Saturation'
   */
  2.0,

  /* Expression: -3
   * Referenced by: '<Root>/Saturation'
   */
  -3.0
};
